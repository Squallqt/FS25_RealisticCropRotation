-- Copyright © 2026 Squallqt. All rights reserved.

RealisticCropRotationHud = {}

RealisticCropRotationHud.HISTORY_LABEL_KEYS = {
    "rcr_hud_previous_n1",
    "rcr_hud_previous_n2",
}


function RealisticCropRotationHud.getFruitTypeDisplayName(fruitType)
    if fruitType == nil then
        return ""
    end

    if g_fruitTypeManager ~= nil and g_fruitTypeManager.getFillTypeByFruitTypeIndex ~= nil
        and fruitType.index ~= nil then
        local fillType = g_fruitTypeManager:getFillTypeByFruitTypeIndex(fruitType.index)
        if fillType ~= nil and fillType.title ~= nil and fillType.title ~= "" then
            return fillType.title
        end
    end

    if fruitType.fillType ~= nil and fruitType.fillType.title ~= nil
        and fruitType.fillType.title ~= "" then
        return fruitType.fillType.title
    end

    return ""
end

function RealisticCropRotationHud.getText(key, fallback)
    if g_i18n ~= nil and g_i18n.getText ~= nil then
        local text = g_i18n:getText(key)
        if text ~= nil and text ~= "" and text ~= key then
            return text
        end
    end

    return fallback or key
end

function RealisticCropRotationHud.getCropDisplayName(cropName)
    if cropName == nil or cropName == "" then
        return ""
    end

    local normalizedName = string.upper(tostring(cropName))

    if g_fruitTypeManager ~= nil and g_fruitTypeManager.getFruitTypeByName ~= nil then
        local fruitType = g_fruitTypeManager:getFruitTypeByName(normalizedName)
        if fruitType ~= nil then
            local fruitTitle = RealisticCropRotationHud.getFruitTypeDisplayName(fruitType)
            if fruitTitle ~= "" then
                return fruitTitle
            end
        end
    end

    if g_fillTypeManager ~= nil and g_fillTypeManager.getFillTypeByName ~= nil then
        local fillType = g_fillTypeManager:getFillTypeByName(normalizedName)
        if fillType ~= nil and fillType.title ~= nil and fillType.title ~= "" then
            return fillType.title
        end
    end

    return normalizedName:sub(1, 1) .. string.lower(normalizedName:sub(2))
end

function RealisticCropRotationHud.getActiveFruitType(data)
    local fruitTypeIndex = data ~= nil and data.lastFruitTypeIndex or nil
    local unknownFruitType = FruitType ~= nil and FruitType.UNKNOWN or 0
    if fruitTypeIndex == nil or fruitTypeIndex == unknownFruitType then
        return nil
    end

    if g_fruitTypeManager == nil or g_fruitTypeManager.getFruitTypeByIndex == nil then
        return nil
    end

    local fruitType = g_fruitTypeManager:getFruitTypeByIndex(fruitTypeIndex)
    if fruitType == nil then
        return nil
    end

    local growthState = data ~= nil and tonumber(data.lastGrowthState) or nil
    if growthState ~= nil then
        if fruitType.getIsCut ~= nil then
            local ok, isCut = pcall(fruitType.getIsCut, fruitType, growthState)
            if ok and isCut then
                return nil
            end
        end

        if fruitType.getIsWithered ~= nil then
            local ok, isWithered = pcall(fruitType.getIsWithered, fruitType, growthState)
            if ok and isWithered then
                return nil
            end
        end
    end

    return fruitType
end

function RealisticCropRotationHud.addHistoryLines(fieldBox, farmlandId)
    if fieldBox == nil or fieldBox.addLine == nil then
        return
    end

    local manager = g_currentMission ~= nil and g_currentMission.realisticCropRotationManager or nil
    if manager == nil or manager.getHistory == nil then
        return
    end

    farmlandId = tonumber(farmlandId)
    if farmlandId == nil or farmlandId == 0 then
        return
    end

    local history = manager:getHistory(farmlandId) or {}
    for index, key in ipairs(RealisticCropRotationHud.HISTORY_LABEL_KEYS) do
        local entry = history[index]
        local cropName = entry ~= nil and entry.crop or nil
        if cropName ~= nil and cropName ~= "" then
            local label = RealisticCropRotationHud.getText(key)
            local value = RealisticCropRotationHud.getCropDisplayName(cropName)
            if value ~= "" then
                fieldBox:addLine(label, value)
            end
        end
    end
end

-- One line per residue-leaving crop in the rotation history: the N-1 crop shows its
-- n1 residue, the N-2 crop its n2. Value = the fixed deposit (cropConfig states)
-- converted to kg N/ha, read live from Precision Farming. Hidden when no active
-- residue. Replaces the old "cover crop: yes/no" line.
-- Cover crops (isCatchCrop) are deposited natively by PF and excluded from rotation
-- history, so they are not shown here.
function RealisticCropRotationHud.addResidueLines(fieldBox, farmlandId)
    if fieldBox == nil or fieldBox.addLine == nil then return end

    local manager = g_currentMission ~= nil and g_currentMission.realisticCropRotationManager or nil
    if manager == nil or manager.getHistory == nil then return end

    farmlandId = tonumber(farmlandId)
    if farmlandId == nil or farmlandId == 0 then return end

    local config = RealisticCropRotation ~= nil and RealisticCropRotation.cropConfig or nil
    local nitrogenConfig = config ~= nil and config.nitrogen or nil
    if nitrogenConfig == nil then return end

    local history = manager:getHistory(farmlandId) or {}
    local n1Crop = history[1] ~= nil and history[1].crop or nil
    local n2Crop = history[2] ~= nil and history[2].crop or nil

    local service = manager.service
    local label = RealisticCropRotationHud.getText("rcr_hud_residue")

    local function emitResidue(cropName, stateChange)
        if cropName == nil or stateChange == nil or stateChange <= 0 then return end
        local kg
        if service ~= nil and type(service.getNitrogenKgFromStates) == "function" then
            kg = service:getNitrogenKgFromStates(stateChange)
        else
            kg = stateChange * RealisticCropRotationService.PF_STATE_PER_UNIT
        end
        local cropDisplay = RealisticCropRotationHud.getCropDisplayName(cropName)
        fieldBox:addLine(string.format("%s (%s)", label, cropDisplay),
            string.format("%d kg/ha", math.floor(kg + 0.5)))
    end

    -- N-1 source -> n1 residue (most recent).
    if n1Crop ~= nil then
        local cfg = nitrogenConfig[string.upper(n1Crop)]
        emitResidue(n1Crop, cfg ~= nil and cfg.n1 or 0)
    end

    -- N-2 source -> n2 residue. Never a second line for the same crop as N-1.
    if n2Crop ~= nil and (n1Crop == nil or string.upper(n2Crop) ~= string.upper(n1Crop)) then
        local cfg = nitrogenConfig[string.upper(n2Crop)]
        emitResidue(n2Crop, cfg ~= nil and cfg.n2 or 0)
    end

    -- Cover crop residue (e.g. oilseed radish): deposited natively by PF on incorporation,
    -- excluded from rotation history, tracked separately. Shown until the next crop is harvested.
    local coverCrop = manager.getLastCover ~= nil and manager:getLastCover(farmlandId) or nil
    if coverCrop ~= nil and coverCrop ~= "" then
        local coverStates = (service ~= nil and type(service.getCoverResidueStateChange) == "function")
            and service:getCoverResidueStateChange() or 0
        emitResidue(coverCrop, coverStates)
    end
end

-- Computes the (tierText, numbers) pair used to override the base game's
-- pedestrian "Croissance:" line for the field hovered by the player. Returns
-- nil for both when the override does not apply (no fruit, terminal state,
-- no i18n). Resolving both here avoids paying the cost on every addLine call.
local function resolveGrowthOverride(data)
    if data == nil or g_fruitTypeManager == nil then return nil, nil end
    if RealisticCropRotationManager == nil then return nil, nil end

    local unknownFruitType = (FruitType ~= nil and FruitType.UNKNOWN) or 0

    local fruitTypeIndex = tonumber(data.fruitTypeIndex)
    if fruitTypeIndex == nil or fruitTypeIndex == unknownFruitType then
        fruitTypeIndex = tonumber(data.lastFruitTypeIndex)
    end
    if fruitTypeIndex == nil or fruitTypeIndex == unknownFruitType then return nil, nil end

    local growthState = tonumber(data.growthState)
    if growthState == nil or growthState <= 0 then
        growthState = tonumber(data.lastGrowthState)
    end
    if growthState == nil or growthState <= 0 then return nil, nil end

    local fruitType = g_fruitTypeManager:getFruitTypeByIndex(fruitTypeIndex)
    if fruitType == nil then return nil, nil end

    local numbers = RealisticCropRotationManager.getGrowthStageNumbers(fruitType, growthState)
    if numbers == nil then return nil, nil end

    local tierText = RealisticCropRotationManager.getGrowthTierText(fruitType, growthState)
    if tierText == nil then return nil, nil end

    return tierText, numbers
end

function RealisticCropRotationHud.fieldAddField(hudSelf, superFunc, data, fieldBox, ...)
    local hookData = data
    local hookFieldBox = fieldBox

    if (hookFieldBox == nil or hookFieldBox.addLine == nil)
            and data ~= nil and data.addLine ~= nil then
        hookFieldBox = data
        hookData = fieldBox
    end

    local tierText, numbers = resolveGrowthOverride(hookData)
    local originalAddLine = nil

    if tierText ~= nil and numbers ~= nil
            and hookFieldBox ~= nil and hookFieldBox.addLine ~= nil then
        originalAddLine = hookFieldBox.addLine
        hookFieldBox.addLine = function(boxSelf, label, value)
            if value == tierText then
                value = string.format("(%s) · %s", numbers, value)
            end
            return originalAddLine(boxSelf, label, value)
        end
    end

    superFunc(hudSelf, data, fieldBox, ...)

    if originalAddLine ~= nil then
        hookFieldBox.addLine = originalAddLine
    end
end

-- Extends PlayerHUDUpdater.fieldAddFarmland with RealisticCropRotation-only complementary
-- rows. Growth replacement is handled exclusively in fieldAddField, which is
-- the runtime function that actually emits the base-game crop/growth rows.
-- Giants Utils.overwrittenFunction calling convention:
--   function(self, superFunc, ...originalArgs)
-- First arg = the object instance (self), second arg = original function.
function RealisticCropRotationHud.fieldAddFarmland(hudSelf, superFunc, data, fieldBox)
    local farmlandId = data ~= nil and data.farmlandId or nil

    superFunc(hudSelf, data, fieldBox)

    RealisticCropRotationHud.addHistoryLines(fieldBox, farmlandId)
    RealisticCropRotationHud.addResidueLines(fieldBox, farmlandId)
end

if PlayerHUDUpdater ~= nil and Utils ~= nil and Utils.overwrittenFunction ~= nil then
    if PlayerHUDUpdater.fieldAddField ~= nil then
        PlayerHUDUpdater.fieldAddField = Utils.overwrittenFunction(PlayerHUDUpdater.fieldAddField, RealisticCropRotationHud.fieldAddField)
    end

    if PlayerHUDUpdater.fieldAddFarmland ~= nil then
        PlayerHUDUpdater.fieldAddFarmland = Utils.overwrittenFunction(PlayerHUDUpdater.fieldAddFarmland, RealisticCropRotationHud.fieldAddFarmland)
    end
end
